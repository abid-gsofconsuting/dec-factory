import React from "react";
export default function Landing() {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-12 d-flex justify-content-center align-items-center">
          <div className={`cardContainer card  m-2`}>
            <div className="card-body p-3">
              <h5>Landing Page</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
