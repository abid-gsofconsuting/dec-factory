export default function Footer() {
  return <footer className={`container-fluid footer `}>Copyright @ Dec-Factory</footer>;
}
